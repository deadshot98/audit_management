﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditManagementPortalClientMVC.Models
{
    public class CQuestions
    {
        public int QuestionNo { get; set; }
        public string Question { get; set; }
    }
}
