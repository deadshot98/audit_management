﻿using AuditManagementPortalClientMVC.Models;
using AuditManagementPortalClientMVC.Models.Context;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AuditManagementPortalClientMVC.Repository
{
    public class SeverityRepo : ISeverityRepo
    {
        private readonly AuditDbContext _auditDbContext;

        public SeverityRepo(AuditDbContext auditDbContext)
        {
            _auditDbContext = auditDbContext;
        }
        public async Task<AuditResponse> GetResponse(AuditRequest auditRequest)
        {
            //AuditRequest auditRequest1 = new AuditRequest
            //{
            //    ProjectName = "Sudipt",
            //    ApplicationOwnerName = "Sudipt",
            //    ProjectManagerName = "LMN",
            //    Auditdetails= new AuditDetail
            //    {
            //        Date = Convert.ToDateTime("12/31/2021 00:00:00"),
            //        Type = "Internal",
            //        questions = new Questions
            //        {
            //            Question1=true,
            //            Question2 = true,
            //            Question3 = false,
            //            Question4 = true,
            //            Question5 = true
            //        }

            //    }
            //};


            //HttpResponseMessage responseMessage = await (new HttpClient()).PostAsJsonAsync("http://localhost:7004/api/AuditSeverity",(auditRequest) );
            //return null;

            AuditResponse auditResponse = new AuditResponse();
            using (var httpClient = new HttpClient())
            {
                //StringContent content = new StringContent(System.Text.Json.JsonSerializer.Serialize(auditRequest), Encoding.UTF8, "application/json");

                //var dataAsString = JsonConvert.SerializeObject(auditRequest);
                //var content = new StringContent(dataAsString);
                //content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                HttpResponseMessage response = await httpClient.PostAsJsonAsync("https://localhost:44398/api/AuditSeverity", auditRequest);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    auditResponse = JsonConvert.DeserializeObject<AuditResponse>(result);
                }

            }
            return auditResponse;
            //throw new NotImplementedException();
        }

        public void StoreResponse(StoreAuditResponse auditResponse) 
        {
            _auditDbContext.storeAuditResponses.Add(auditResponse);
            _auditDbContext.SaveChanges();

        }

    }
}
