﻿using AuditManagementPortalClientMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditManagementPortalClientMVC.Repository
{
    public class UserRepo : IUserRepo
    {
        public List<User> GetUsers()
        {
            List<User> users = new List<User>()
            {
            new User{Name = "Sudipt", Password ="Kumar" },
            new User{Name = "Sayantani", Password ="Barman" },
            new User{Name = "Nisha", Password ="Nisha" },
            new User{Name = "Biswajit", Password ="Nandi" }
            };
            return users;
        }
    }
}
